from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer


def featuresFromTfIdf(str):
    # Create a TfidfVectorizer object
    vectorizer = TfidfVectorizer()
    # Fit and transform the sentence using TfidfVectorizer
    features = vectorizer.fit_transform([str])
    return features

def featuresFromBow(str):
    # Bag of Words
    count_vect = CountVectorizer()
    bow = count_vect.fit_transform(str)
    return bow

